create function polygon(circle) returns polygon
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function polygon(circle) is 'convert circle to 12-vertex polygon';

alter function polygon(circle) owner to postgres;

