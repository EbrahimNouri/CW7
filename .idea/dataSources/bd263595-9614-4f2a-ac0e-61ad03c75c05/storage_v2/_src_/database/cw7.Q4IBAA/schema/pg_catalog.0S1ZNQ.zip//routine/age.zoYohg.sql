create function age(timestamp, timestamp) returns interval
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function age(timestamp, timestamp) is 'date difference preserving months and years';

alter function age(timestamp, timestamp) owner to postgres;

